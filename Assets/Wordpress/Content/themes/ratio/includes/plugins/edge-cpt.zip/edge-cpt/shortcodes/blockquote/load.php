<?php

include_once EDGE_CORE_ABS_PATH.'/shortcodes/blockquote/blockquote.php';