<div class="edgtf-vss-ms-section" <?php ratio_edge_inline_style($content_style);?>>
	<?php echo do_shortcode($content); ?>
</div>