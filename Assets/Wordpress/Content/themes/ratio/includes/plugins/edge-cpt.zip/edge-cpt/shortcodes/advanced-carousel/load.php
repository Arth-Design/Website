<?php
require_once EDGE_CORE_ABS_PATH.'/shortcodes/advanced-carousel/advanced-carousel.php';