<?php

include_once EDGE_CORE_ABS_PATH.'/shortcodes/tooltip/tooltip.php';