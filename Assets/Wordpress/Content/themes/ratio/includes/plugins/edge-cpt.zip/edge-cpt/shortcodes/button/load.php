<?php

include_once EDGE_CORE_ABS_PATH.'/shortcodes/button/options-map/map.php';
include_once EDGE_CORE_ABS_PATH.'/shortcodes/button/custom-styles/custom-styles.php';
include_once EDGE_CORE_ABS_PATH.'/shortcodes/button/button.php';