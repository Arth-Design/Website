<?php
require_once EDGE_CORE_ABS_PATH.'/shortcodes/crossfade-slider/crossfade-slider.php';
require_once EDGE_CORE_ABS_PATH.'/shortcodes/crossfade-slider/crossfade-slide.php';