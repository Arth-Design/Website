<?php
require_once EDGE_CORE_ABS_PATH.'/shortcodes/elements-holder/elements-holder.php';
require_once EDGE_CORE_ABS_PATH.'/shortcodes/elements-holder/elements-holder-item.php';
