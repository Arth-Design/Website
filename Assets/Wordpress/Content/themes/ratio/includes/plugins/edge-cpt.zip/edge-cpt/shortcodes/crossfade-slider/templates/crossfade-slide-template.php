<div class="edgtf-crossfade-slide">
	<div class="edgtf-crossfade-slide-table">
		<div class="edgtf-crossfade-slide-cell">
			<?php echo wp_get_attachment_image($slide_image,'full'); ?>
		</div>
	</div>
</div>

